const expect = require('chai').expect;

describe('dz0/semantic-mockup', () => {
  it('семантическая разметка страницы', () => {
    expect(1).to.equal(1);
  });
});
