const expect = require('chai').expect;

describe('lection5/radio', () => {
  it('Радио', () => {
    expect(1).to.equal(1);
  });
});
