const expect = require('chai').expect;

describe('lection5/input', () => {
  it('Поле ввода', () => {
    expect(1).to.equal(1);
  });
});
