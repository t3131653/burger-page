# Чекбокс

figma: [https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=18342%3A1](https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=18342%3A1)

Реализовать нужно правильное отображений состояний:
- `:focus`
- `:checked`
- `:disabled`
- их сочетаний

Нужно предусмотреть возможность доступа с клавиатуры - по нажатию на `tab` можно переключиться на конкретный `checkbox`, а нажимая на пробел активировать или деактивировать его.

Чтобы было понятно, какой чекбокс сейчас в фокусе, нужно подчеркивать текст лейбла чекбокса.
