const expect = require('chai').expect;

describe('lection5/checkbox', () => {
  it('Чекбокс', () => {
    expect(1).to.equal(1);
  });
});
