# Toggler

figma: [https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=18342%3A1](https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=18342%3A1)

Toggler или "кнопка переключения" вошла в нашу жизнь через мобильные устройства.
За необычным внешним видом скрывается тот же `checkbox`.

И требования те же - состояния `:disabled`, `:checked`, `:focus` и их сочетания.
Текст лейбла для удобства навигации через `tab` при `:focus` нужно подчеркнуть.

Анимацию пока не делаем, добавим позже.
