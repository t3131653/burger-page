const expect = require('chai').expect;

describe('lection5/toggler', () => {
  it('Toggler', () => {
    expect(1).to.equal(1);
  });
});
