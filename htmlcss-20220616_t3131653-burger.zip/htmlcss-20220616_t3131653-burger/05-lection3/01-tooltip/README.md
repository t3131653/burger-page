# Тултип

figma: [https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17325%3A297](https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17325%3A297)

Сделать нужно так, чтобы подсказка в тултипе показывалась по наведению на вопросик, остальное разбирали на лекции.