const expect = require('chai').expect;

describe('lection3/tooltip', () => {
  it('Тултип', () => {
    expect(1).to.equal(1);
  });
});
