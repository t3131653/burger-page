const expect = require('chai').expect;

describe('lection3/modal', () => {
  it('Модалка', () => {
    expect(1).to.equal(1);
  });
});
