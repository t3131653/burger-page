# Календарь

figma: [https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17325%3A248](https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17325%3A248)

Подробно обсудили этот блок на лекции, основные требования к календарю:
- надо сверстать на гридах
- должен быть резиновым - при увеличении ширины блока он должен сохранять пропорции, не должен разваливаться
