const expect = require('chai').expect;

describe('lection3/calendar', () => {
  it('Календарь', () => {
    expect(1).to.equal(1);
  });
});
