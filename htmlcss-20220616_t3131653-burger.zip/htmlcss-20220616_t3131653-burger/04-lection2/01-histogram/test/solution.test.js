const expect = require('chai').expect;

describe('lection2/histogram', () => {
  it('Гистограмма', () => {
    expect(1).to.equal(1);
  });
});
