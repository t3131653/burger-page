# Гистограмма

figma: [https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17318%3A1](https://www.figma.com/file/LavZmQfQccqyrTMzoSJYNu/CSS-Course?node-id=17318%3A1)

Сделать нужно так, чтобы гистограмма растягивалась на максимальную ширину контейнера. Столбики, отражающие данные, будут иметь переменную ширину. Их количество при разработке, конечно же, неизвестно и может варьироваться.
