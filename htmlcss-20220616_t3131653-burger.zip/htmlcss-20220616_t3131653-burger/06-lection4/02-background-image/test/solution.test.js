const expect = require('chai').expect;

describe('lection4/background-image', () => {
  it('Фон', () => {
    expect(1).to.equal(1);
  });
});
