const expect = require('chai').expect;

describe('lection4/avatar', () => {
  it('Аватарка', () => {
    expect(1).to.equal(1);
  });
});
