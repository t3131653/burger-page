const expect = require('chai').expect;

describe('intro/hello-world', () => {
  it('вводная задача', () => {
    expect(1).to.equal(1);
  });
});
