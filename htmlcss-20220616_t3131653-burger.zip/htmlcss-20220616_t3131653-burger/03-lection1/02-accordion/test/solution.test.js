const expect = require('chai').expect;

describe('lection1/accordion', () => {
  it('Аккордеон', () => {
    expect(1).to.equal(1);
  });
});
