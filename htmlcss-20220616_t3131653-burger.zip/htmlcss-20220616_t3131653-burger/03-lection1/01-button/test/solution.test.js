const expect = require('chai').expect;

describe('lection1/button', () => {
  it('Кнопка', () => {
    expect(1).to.equal(1);
  });
});
